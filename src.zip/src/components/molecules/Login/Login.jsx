import React from 'react'
import Button from '../../atoms/Button'
import Form from '../../atoms/Form/Form'
import Input from '../../atoms/Input/Input'
import Label from '../../atoms/Label/Label'

export default function Login() {
  return (
    <Form>
        <Label HTMLfor="name">name</Label>
        <Input type="text"/>
        <Label>username</Label>
        <Input type="text"/>
        <Label>email</Label>
        <Input type="email"/>
        <Label>password</Label>
        <Input type="password"/>
        <Button className="bg-black text-white">Login</Button>
    </Form>
  )
}
