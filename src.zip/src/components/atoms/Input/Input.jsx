import React from 'react'

export default function Input({type,onChangeHandler,ariaLable,HTMLfor,name}) {
  return (
    <input type={type} HTMLfor={HTMLfor} name={name} onChange={()=>{onChangeHandler()}} aria-labelledby={ariaLable} />
  )
}
