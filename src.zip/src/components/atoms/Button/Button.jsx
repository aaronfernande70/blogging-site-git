import React from "react";

const Button = ({ onCLickHandler, className, children, ariaLabel }) => (
    <button
        className={className}
        type="button"
        onClick={onCLickHandler}
        aria-label={ariaLabel}
    >
        {children}
    </button>
);

export default Button;
