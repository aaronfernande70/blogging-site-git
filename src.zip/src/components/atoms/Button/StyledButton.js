
import styled from 'styled-components'
  
const StyledButton = styled.button`
    color :  ;
    background-color : ${props => props.bg? props.bg : "black"};
    width : fit-content;
    padding : 2px 10px;
    margin : 10px auto;
`

  
export default StyledButton;