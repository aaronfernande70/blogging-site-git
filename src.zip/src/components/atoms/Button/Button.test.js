// import React from "react";
// import { render } from "@testing-library/react";


// test("button atom is rendering", () => {
//     const { getByText } = render(<button>Submit</button>);
//     const buttonElement = getByText(/Submit/i);
//     expect(buttonElement).toBeInTheDocument();
// });
