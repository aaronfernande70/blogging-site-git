import React from 'react'
import Button from './components/atoms/Button'
import Login from './components/molecules/Login/Login'

export default function App() {
  return (
    <React.Fragment>
      <Login/>
    </React.Fragment>
  )
}
